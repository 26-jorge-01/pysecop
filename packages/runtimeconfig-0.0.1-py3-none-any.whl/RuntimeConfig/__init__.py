from .logging_setup import init_logging, get_logger

__all__ = ['init_logging', 'get_logger']

try:
    from .db_connection import get_connection
    __all__.append('get_connection')
except ImportError:
    HAS_MATPLOTLIB = False