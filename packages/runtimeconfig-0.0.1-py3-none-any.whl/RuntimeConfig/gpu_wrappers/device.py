# ml_wrappers/device.py
from __future__ import annotations

import os
import torch

from dataclasses import dataclass
from ..logging_setup import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class DeviceConfig:
    use_cuda: bool
    device: torch.device
    n_gpus: int
    dtype_fp32: torch.dtype = torch.float32
    dtype_fp16: torch.dtype = torch.float16

    @property
    def primary_device_str(self) -> str:
        return str(self.device)


def _detect_device() -> DeviceConfig:
    force_cpu = os.getenv("ML_FORCE_CPU", "0").lower() in {"1", "true", "yes"}

    has_cuda = torch.cuda.is_available()
    n_gpus = torch.cuda.device_count() if has_cuda else 0

    if force_cpu or not has_cuda:
        return DeviceConfig(
            use_cuda=False,
            device=torch.device("cpu"),
            n_gpus=0,
        )

    # Por defecto usamos la primera GPU
    return DeviceConfig(
        use_cuda=True,
        device=torch.device("cuda:0"),
        n_gpus=n_gpus,
    )


# Config global que usarán todos los wrappers
DEVICE_CONFIG = _detect_device()


def get_device() -> torch.device:
    """
    Devuelve el torch.device a usar en todo el proyecto.
    """

    return DEVICE_CONFIG.device


def is_cuda_available() -> bool:
    return DEVICE_CONFIG.use_cuda


def get_default_dtype() -> torch.dtype:
    """
    Puedes usar esto si quieres forzar FP16 en GPU, FP32 en CPU.
    """

    if DEVICE_CONFIG.use_cuda:
        return DEVICE_CONFIG.dtype_fp16

    return DEVICE_CONFIG.dtype_fp32
