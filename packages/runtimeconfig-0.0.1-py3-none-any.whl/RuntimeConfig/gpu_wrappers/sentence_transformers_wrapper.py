from __future__ import annotations

from typing import Iterable

from sentence_transformers import SentenceTransformer

from .device import is_cuda_available


class SentenceTransformerWrapper:
    """
    Wrapper alrededor de SentenceTransformer que:
      - Detecta automáticamente CPU vs GPU.
      - Siempre usa el mismo device que el resto del proyecto.
    """

    def __init__(self, model_name: str, **kwargs):
        device = "cuda" if is_cuda_available() else "cpu"
        # sentence-transformers ya entiende 'device'
        self._model = SentenceTransformer(model_name, device=device, **kwargs)

    @property
    def model(self) -> SentenceTransformer:
        return self._model

    def encode(
        self,
        sentences: Iterable[str],
        batch_size: int = 32,
        convert_to_tensor: bool = True,
        **kwargs,
    ):
        """
        encode que ya usa el device correcto y por defecto devuelve tensores.
        """

        return self._model.encode(
            sentences,
            batch_size=batch_size,
            convert_to_tensor=convert_to_tensor,
            **kwargs,
        )

    def __call__(self, sentences: Iterable[str], **kwargs):
        return self.encode(sentences, **kwargs)
