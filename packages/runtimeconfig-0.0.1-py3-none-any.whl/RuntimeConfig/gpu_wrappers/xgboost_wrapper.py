# ml_wrappers/xgboost_wrapper.py
from __future__ import annotations

from typing import Any, Dict, Optional

from xgboost import XGBClassifier, XGBRegressor

from .device import is_cuda_available


def _base_xgb_params(
    user_params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Devuelve parámetros base para XGBoost, ajustando device y tree_method.
    """

    params: Dict[str, Any] = {}

    if user_params:
        params.update(user_params)

    if is_cuda_available():
        # XGBoost 2.x: device='cuda' y tree_method='hist' o 'approx'.
        params.setdefault("device", "cuda")
        params.setdefault("tree_method", "hist")
    else:
        params.setdefault("device", "cpu")
        params.setdefault("tree_method", "hist")

    return params


def create_xgb_classifier(
    **user_params,
) -> XGBClassifier:
    """
    Crea un XGBClassifier con configuración adecuada a CPU/GPU.
    """

    params = _base_xgb_params(user_params)
    return XGBClassifier(**params)


def create_xgb_regressor(
    **user_params,
) -> XGBRegressor:
    """
    Crea un XGBRegressor con configuración adecuada a CPU/GPU.
    """

    params = _base_xgb_params(user_params)
    return XGBRegressor(**params)
