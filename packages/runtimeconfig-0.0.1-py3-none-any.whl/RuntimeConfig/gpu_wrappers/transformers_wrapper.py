from __future__ import annotations

from typing import Tuple, Type

import torch
from transformers import (
    AutoModel,
    AutoModelForSequenceClassification,
    AutoModelForSeq2SeqLM,
    AutoTokenizer,
    PreTrainedModel,
    PreTrainedTokenizerBase,
)

from .device import get_device, is_cuda_available, DEVICE_CONFIG


def load_transformer_base(
    model_name: str,
    model_cls: Type[PreTrainedModel] = AutoModel,
    use_half_if_gpu: bool = True,
    **model_kwargs,
) -> Tuple[PreTrainedTokenizerBase, PreTrainedModel]:
    """
    Carga un modelo de transformers + tokenizer en el dispositivo correcto.

    - Si hay GPU: usa device_map="auto" + dtype float16 (opcional).
    - Si no hay GPU: CPU normal.
    """

    tokenizer = AutoTokenizer.from_pretrained(model_name)

    if is_cuda_available():
        torch_dtype = (
            torch.float16
            if use_half_if_gpu and DEVICE_CONFIG.dtype_fp16 is not None
            else torch.float32
        )
        model = model_cls.from_pretrained(
            model_name,
            device_map="auto",
            torch_dtype=torch_dtype,
            **model_kwargs,
        )

    else:
        # CPU: cargamos normal y movemos al device global (cpu)
        model = model_cls.from_pretrained(
            model_name,
            **model_kwargs,
        )
        model.to(get_device())

    return tokenizer, model


def load_encoder_model(
    model_name: str,
    use_half_if_gpu: bool = True,
    **kwargs,
) -> Tuple[PreTrainedTokenizerBase, PreTrainedModel]:

    return load_transformer_base(
        model_name=model_name,
        model_cls=AutoModel,
        use_half_if_gpu=use_half_if_gpu,
        **kwargs,
    )


def load_seq_classification_model(
    model_name: str,
    use_half_if_gpu: bool = True,
    **kwargs,
) -> Tuple[PreTrainedTokenizerBase, PreTrainedModel]:

    return load_transformer_base(
        model_name=model_name,
        model_cls=AutoModelForSequenceClassification,
        use_half_if_gpu=use_half_if_gpu,
        **kwargs,
    )


def load_seq2seq_model(
    model_name: str,
    use_half_if_gpu: bool = True,
    **kwargs,
) -> Tuple[PreTrainedTokenizerBase, PreTrainedModel]:

    return load_transformer_base(
        model_name=model_name,
        model_cls=AutoModelForSeq2SeqLM,
        use_half_if_gpu=use_half_if_gpu,
        **kwargs,
    )
