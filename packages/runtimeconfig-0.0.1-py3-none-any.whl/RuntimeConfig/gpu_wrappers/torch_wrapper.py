from __future__ import annotations

from typing import Any, Iterable, Optional

import torch
from torch import nn

from .device import get_device, is_cuda_available, DEVICE_CONFIG


def move_model_to_device(model: nn.Module) -> nn.Module:
    """
    Mueve el modelo al dispositivo correcto (CPU o GPU).
    Lo usas una vez después de crear/cargar el modelo.
    """

    device = get_device()
    model.to(device)

    return model


def tensor(
    data: Any,
    dtype: Optional[torch.dtype] = None,
    requires_grad: bool = False,
) -> torch.Tensor:
    """
    Crea un tensor directamente en el dispositivo adecuado.
    """

    device = get_device()
    if dtype is None:
        dtype = DEVICE_CONFIG.dtype_fp32

    return torch.tensor(
        data, device=device, dtype=dtype, requires_grad=requires_grad
    )


def to_device(x: torch.Tensor | Iterable[torch.Tensor]) -> torch.Tensor | list[torch.Tensor]:
    """
    Mueve uno o varios tensores al dispositivo adecuado.
    """

    device = get_device()

    if isinstance(x, torch.Tensor):
        return x.to(device)

    return [t.to(device) for t in x]


def get_torch_summary() -> str:
    return (
        f"device={DEVICE_CONFIG.device}, "
        f"use_cuda={DEVICE_CONFIG.use_cuda}, "
        f"n_gpus={DEVICE_CONFIG.n_gpus}"
    )


def empty_cache_if_gpu():
    """
    Limpia la memoria GPU si estás en CUDA. No hace nada en CPU.
    Útil en pipelines largos.
    """

    if is_cuda_available():
        torch.cuda.empty_cache()
