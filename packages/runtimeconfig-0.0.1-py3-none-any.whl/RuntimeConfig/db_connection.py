# Standard and Database libraries
import asyncpg
from urllib.parse import urlparse, urlunparse


def get_asyncpg_dsn(sqlalchemy_dsn: str) -> str:
    parsed = urlparse(sqlalchemy_dsn)
    # Drop the '+asyncpg' part
    scheme = parsed.scheme.split('+')[0]
    parsed = parsed._replace(scheme=scheme)

    return urlunparse(parsed)


# Conexión establecida en backend (emulación para los inputs del paquete)
async def get_connection(db_connection_string_async) -> asyncpg.Connection:
    try:
        dsn = get_asyncpg_dsn(db_connection_string_async)
        conn = await asyncpg.connect(dsn)
        return conn

    except asyncpg.exceptions.InvalidCatalogNameError:
        raise Exception(
            "Database does not exist. Check your connection string."
        )

    except asyncpg.exceptions.InvalidPasswordError:
        raise Exception(
            "Invalid database credentials. Check username/password."
        )

    except asyncpg.exceptions.ConnectionDoesNotExistError:
        raise Exception(
            "Cannot establish database connection. Check if database server is running."
        )

    except asyncpg.exceptions.ConnectionFailureError as e:
        raise Exception(f"Database connection failed: {str(e)}")

    except Exception as e:
        raise Exception(f"Unexpected error connecting to database: {str(e)}")
